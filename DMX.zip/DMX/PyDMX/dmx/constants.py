"""Module containing constants of the DMX standard."""

DMX_MAX_ADDRESS = 512
DMX_MIN_ADDRESS = 1
DMX_EMPTY_BYTE = 0x00
