import dmx
import time
mydmx = dmx.DMXConnection(5)
channel = 2
mydmx.setChannel(channel, 128, autorender=True)
time.sleep(2)
mydmx.setChannel(channel, 0, autorender=True)
time.sleep(2)
mydmx.setChannel(channel, 255, autorender=True)